package com.cute.cat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
public class CuteCat444444Teams extends JavaPlugin {
 private final String[] names={"red","blue","green","yellow"};
 public void onEnable(){ for(String n:names) if(getCommand(n)!=null)getCommand(n).setExecutor((s,c,l,a)->join(s,c.getName())); setup(); }
 private void setup(){ Scoreboard b=Bukkit.getScoreboardManager().getMainScoreboard(); create(b,"red",ChatColor.RED);create(b,"blue",ChatColor.BLUE);create(b,"green",ChatColor.GREEN);create(b,"yellow",ChatColor.YELLOW); }
 private void create(Scoreboard b,String n,ChatColor c){Team t=b.getTeam(n);if(t==null)t=b.registerNewTeam(n);t.setColor(c);t.setPrefix(c+"["+n.toUpperCase()+"] "+ChatColor.RESET);}
 private boolean join(CommandSender s,String n){if(!(s instanceof Player p)){s.sendMessage("Only players can use this command.");return true;} Scoreboard b=Bukkit.getScoreboardManager().getMainScoreboard();for(Team t:b.getTeams())t.removeEntry(p.getName());Team t=b.getTeam(n);if(t!=null){t.addEntry(p.getName());p.sendMessage(Component.text("Ты вступил в команду "+n+"!",color(n)));}return true;}
 private NamedTextColor color(String n){return switch(n){case "red"->NamedTextColor.RED;case "blue"->NamedTextColor.BLUE;case "green"->NamedTextColor.GREEN;default->NamedTextColor.YELLOW;};}
}
